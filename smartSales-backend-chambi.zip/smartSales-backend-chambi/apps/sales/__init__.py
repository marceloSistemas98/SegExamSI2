default_app_config = 'apps.sales.apps.SalesConfig'
