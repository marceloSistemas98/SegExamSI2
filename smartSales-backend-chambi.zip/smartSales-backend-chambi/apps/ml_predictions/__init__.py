default_app_config = 'apps.ml_predictions.apps.MlPredictionsConfig'
