# Configuración de settings para SmartSales365
